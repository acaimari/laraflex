/**
 * @license Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'codesnippet', 'tt', {
	button: 'Код өзеген өстәү',
	codeContents: 'Код эчтәлеге',
	emptySnippetError: 'Код өзеге буш булмаска тиеш.',
	language: 'Тел',
	title: 'Код өзеге',
	pathName: 'код өзеге'
} );
